<?php

    require "vendor/autoload.php";

    $app=new Slim\App([
        'settings'=>[
            'displayErrorDetails'=>true,     // true-> Making allowing Error Details, ... default displayErrorDetails is false in slim/container.php so we have to change setting of displayErrorDetails is true
        ]        
    ]);

    $app->get('/',function(){

        echo "Example of Error Details";

    });

    $app->run();

?>