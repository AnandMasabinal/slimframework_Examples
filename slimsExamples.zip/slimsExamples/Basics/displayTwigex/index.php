<?php

//Before we Start twig examples we have to install twig with command - composer require slim/twig-view:3.0.0-beta
//then getContainer
// Register Component on container
// set path with - __DIR__.'/resources/view

    require "vendor/autoload.php";

    $app=new Slim\App([
        'setting'=>[
            'displayErrorDetails'=>true,
        ]
    ]);

    $container=$app->getContainer();

    $container['view'] = function ($container) {
        $view = new \Slim\Views\Twig(__DIR__.'/resources/view', [
            'cache' => false
        ]);
    
        // Instantiate and add Slim specific extension
        $router = $container->get('router');
        $uri = \Slim\Http\Uri::createFromEnvironment(new \Slim\Http\Environment($_SERVER));
        $view->addExtension(new \Slim\Views\TwigExtension($router, $uri));
    
        return $view; // it should return the view
    };

    $app->get('/',function($request,$response){
        
        return $this->view->render($response,'home.twig'); /// this line is render the template defined in folder
    });

    $app->get('/user',function($request,$response){
        return $this->view->render($response,'user.twig');
    });

    $app->run();
?>