<?php

require "vendor/autoload.php";

$app=new Slim\App();

$app->get('/',function(){
    echo "Welcome To Home Page";
});

$app->get('/about',function(){

    echo "This is About us Pgae";
});

$app->run();

?>