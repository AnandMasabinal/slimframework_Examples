<?php

        //DI Container it is an optional DI to prepare, manage and Inject application dependencies


require 'vendor/autoload.php';

$app=new Slim\App();

$container=$app->getContainer();

$container['greeting']=function(){
    return "Hi Container wel come";
};

$app->get('/',function(){
    echo $this->greeting;
});

$app->run();

?>