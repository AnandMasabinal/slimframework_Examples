<?php

require "vendor/autoload.php";

$app=new Slim\App([
    'setting'=>[
        'displayErrorDetails'=>true,
    ]
]);

$container=$app->getContainer();

$container['view'] = function ($container) {
    $view = new \Slim\Views\Twig(__DIR__.'/resources/views', [
        'cache' => false
    ]);

    // Instantiate and add Slim specific extension
    $router = $container->get('router');
    $uri = \Slim\Http\Uri::createFromEnvironment(new \Slim\Http\Environment($_SERVER));
    $view->addExtension(new \Slim\Views\TwigExtension($router, $uri));

    return $view;
};




$app->get('/',function($request,$response){
    $user=[
        ['user'=>'1'],
        ['user'=>'2'],
        ['user'=>'3']
    ];
    return $this->view->render($response,'home.twig',[
        'users'=>$user    //passing array value with response to home.twig
    ]);
});



$app->get('/contact',function($request,$response){
    return $this->view->render($response,'contact.twig');
});

$app->run();

?>